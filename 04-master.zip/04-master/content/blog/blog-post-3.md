---
title: "Yves Saint Laurent Biography"
date: 2019-11-23T15:28:43+06:00
draft: false

# post author
author : "themefisher"

# post thumb
image: "images/blog/blog-1.jpg"

# meta description
description: "this is meta description"

# taxonomies
categories: ["Creative"]
tags: ["Photos", "HTML", "Book", "New"]
# post type
type: "post"
---


Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus natus, consectetur? Illum libero vel
nihil nisi quae, voluptatem, sapiente necessitatibus distinctio voluptates, iusto qui. Laboriosam autem,
nam voluptate in beatae.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam officiis perspiciatis, eaque porro ad
facilis vel amet. Pariatur eligendi odio voluptatem provident modi eos, perferendis quas delectus.
Dolore, quo. Ad.


> A brand for a company is like a reputation for a person. You earn reputation by
trying to do hard things well.

## We are leading industry to build your career

The same is true as we experience the emotional sensation of
stress from our first instances of social rejection ridicule. We quickly learn to fear and thus
automatically.


Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel sunt, neque voluptatibus excepturi
laboriosam possimus adipisci quidem dolores omnis, nemo dolore eligendi blanditiis voluptatem in,
doloribus hic aperiam maiores fugit.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, rerum beatae repellat
tenetur incidunt quisquam libero dolores laudantium. Nesciunt quis itaque quidem, voluptatem autem eos
animi laborum iusto expedita sapiente.
                