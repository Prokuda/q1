Yves Saint Laurent was best known as an influential European fashion designer who impacted fashion in the 1960s to the present day.
